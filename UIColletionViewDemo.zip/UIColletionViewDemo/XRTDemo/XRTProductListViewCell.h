//
//  XRTProductListViewCell.h
//  XRTDemo
//
//  Created by wyy on 16/5/16.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XRTProductResponseCellDelegate.h"
#import "XRTProductInfo.h"
#import "XRTHeader.h"

@interface XRTProductListViewCell : UICollectionViewCell
@property (nonatomic, weak) id<XRTProductResponseCellDelegate> delegate;
@property (nonatomic, strong) XRTProductInfo *productInfo;
@property (nonatomic, assign) XRTCellDisplayType type;
@end




