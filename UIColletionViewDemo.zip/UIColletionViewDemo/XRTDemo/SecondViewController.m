//
//  SecondViewController.m
//  XRTDemo
//
//  Created by wyy on 16/11/14.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "SecondViewController.h"
#import "XRTHeader.h"
#import "XRTCollectionLayout.h"
#define cellID @"cellID"

@interface SecondViewController () <UICollectionViewDelegate ,UICollectionViewDataSource>
@property (nonatomic ,strong) UICollectionView *collctionView;
@property (nonatomic, strong) XRTCollectionLayout *layout;
@property (nonatomic, strong) NSMutableArray *dataArr;
@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton*rightButton = [[UIButton alloc]initWithFrame:CGRectMake(0,0,30,30)];
    [rightButton setImage:[UIImage imageNamed:@"delete.png"]forState:UIControlStateNormal];
    [rightButton addTarget:self action:@selector(exchangeIcon:) forControlEvents:UIControlEventTouchUpInside];
    rightButton.selected = NO;
    UIBarButtonItem*rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightButton];
    self.navigationItem.rightBarButtonItem= rightItem;
    
    
    self.dataArr = [NSMutableArray array];
    int index = 8;
    while (index) {
        [self.dataArr addObject:[NSString stringWithFormat:@"%d",index]];
        index--;
    }
    
    self.edgesForExtendedLayout = NO;
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.collctionView];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - action
- (void)exchangeIcon:(UIButton *)sender{
    if (!self.dataArr.count) return;
      long index = (random()/self.dataArr.count)%self.dataArr.count;
      [self.dataArr removeObjectAtIndex:index];
      [self.collctionView deleteItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:0]]];
    

}
#pragma mark - UIcollectionView dataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    cell.backgroundColor = [UIColor randomColor];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [self.dataArr insertObject:@"" atIndex:indexPath.row];
    [collectionView insertItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:indexPath.row inSection:0]]];    
}

#pragma mark - get
- (UICollectionView *)collctionView{
    if (!_collctionView) {
      
        //设置滑动的方向
        _collctionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeigth - 49 - 64 )
                                            collectionViewLayout:self.layout];
        _collctionView.backgroundColor = [UIColor whiteColor];
        //签订协议
        _collctionView.dataSource = self;
        _collctionView.delegate   =self;
        
        //注册cell
        [_collctionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:cellID];
        
        
    }
    return _collctionView;
}

- (XRTCollectionLayout *)layout{
    if (_layout == nil ) {
        _layout = [[XRTCollectionLayout alloc] init];
    }
    return _layout;
}
@end
