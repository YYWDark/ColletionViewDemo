//
//  XRTlargerImagemodeLayout.m
//  XRTDemo
//
//  Created by wyy on 16/11/11.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "XRTlargerImagemodeLayout.h"
static const CGFloat proportion = 9.2/16.0; /* width/height */
static const CGFloat horizontalDistance = 2.0;
static const CGFloat verticalDistance = 2.0;
@interface XRTlargerImagemodeLayout ()
@property (nonatomic, strong) NSMutableArray *layoutAttrinutes;

@end

@implementation XRTlargerImagemodeLayout
- (void)prepareLayout{
    [super prepareLayout];
    NSLog(@"prepareLayout1");
    for (int index = 0; index<[self.collectionView numberOfItemsInSection:0]; index++) {
        NSIndexPath *  indexPath =[NSIndexPath indexPathForItem:index inSection:0];
        UICollectionViewLayoutAttributes * attrs=[self layoutAttributesForItemAtIndexPath:indexPath];
        [self.layoutAttrinutes addObject:attrs];
    }
}
#pragma mark - override
-(UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat width =(self.collectionView.frame.size.width - horizontalDistance)/2;
    CGFloat height =self.collectionView.frame.size.width*proportion;
    UICollectionViewLayoutAttributes * attrs=[UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
    attrs.frame = CGRectMake((width+horizontalDistance)*(indexPath.row%2), (height + verticalDistance)*(indexPath.row/2) , width, height);
    return attrs;
}

//// return an array layout attributes instances for all the views in the given rect
-(NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect
{
    return self.layoutAttrinutes;
}

//// Subclasses must override this method and use it to return the width and height of the collection view’s content
-(CGSize)collectionViewContentSize
{
    int count =(int)[self.collectionView numberOfItemsInSection:0];
    CGFloat height =self.collectionView.frame.size.width*proportion;
    return CGSizeMake(self.collectionView.frame.size.width,height*(count/2 +count%2) +verticalDistance *count/2 +count%2 -1);
}

#pragma mark - get
- (NSMutableArray *)layoutAttrinutes{
    if (_layoutAttrinutes == nil) {
        _layoutAttrinutes = [NSMutableArray array];
    }
    return _layoutAttrinutes;
}

@end
