//
//  XRTProductInfo.m
//  XRTDemo
//
//  Created by wyy on 16/5/16.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "XRTProductInfo.h"

@implementation XRTProductInfo

@end
