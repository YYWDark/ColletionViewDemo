//#7	0x00000001050bc27f in main at /Users/wyy/Desktop/wyy/code/test/XRTDemo 2/XRTDemo/main.m:14

//  main.m
//  XRTDemo
//
//  Created by wyy on 16/5/16.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
