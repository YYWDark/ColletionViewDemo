//
//  XRTProductListViewCell.m
//  XRTDemo
//
//  Created by wyy on 16/5/16.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "XRTProductListViewCell.h"
#import "UIView+XRTExtendTouchRect.h"

@interface XRTProductListViewCell()
@property (nonatomic ,strong) UIImageView *photoImageView;
@property (nonatomic ,strong) UILabel  *describeLable;
@property (nonatomic ,strong) UILabel  *priceLabel;
@property (nonatomic ,strong) UIButton *shoppingButton;
@property (nonatomic ,strong) UIButton *collectButton;

//布局信息
//@property (nonatomic ,assign) CGFloat theDistanceBetweenSC; /**< 购物车和收藏之间的距离*/
//@property (nonatomic ,assign) CGFloat theDistanceColToRigth; /**< 收藏到右边缘的距离*/
//@property (nonatomic ,assign) CGFloat theDistanceDesToRigthAndLeft; /**< 商品描述到左右两边的距离*/
//@property (nonatomic ,assign) CGFloat theDistancePriceToLeft; /**< 价格到左边的距离*/
//@property (nonatomic ,assign) CGFloat theDistanceToBottom; /**< 价格到底部的距离*/
//@property (nonatomic ,assign) CGFloat theDistanceBetweenPD; /**< 价格到描述的距离*/
//@property (nonatomic ,assign) CGFloat theDistanceBetweenDP; /**< 描述到图片的距离*/
//@property (nonatomic ,assign) CGFloat imageViewWidth;       /**< 商品图片的长*/
//@property (nonatomic ,assign) CGFloat imageViewHeigth;      /**< 商品图片的宽*/
//@property (nonatomic ,assign) CGFloat iconSide;             /**< 收藏 购物的宽高*/
@end
@implementation XRTProductListViewCell
#pragma mark - life circle
- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        [self addSubview:self.photoImageView];
        [self addSubview:self.describeLable];
        [self addSubview:self.priceLabel];
        [self addSubview:self.shoppingButton];
        [self addSubview:self.collectButton];
        [self setNeedsLayout];
    }
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];
     if (self.type == XRTCellDisplayTypeLarger) {
    _priceLabel.frame = CGRectMake(15, CGRectGetHeight(self.frame) - 25 - 13.5, 50, 25);
    _collectButton.frame =CGRectMake(CGRectGetWidth(self.frame)- 12.0 -25, CGRectGetHeight(self.frame) - 25 - 13.5 , 25, 25);
    _shoppingButton.frame =CGRectMake(CGRectGetWidth(self.frame) - 2*25 - 17 -12 , CGRectGetHeight(self.frame) - 25-13.5, 25, 25);
    _describeLable.frame = CGRectMake(15, CGRectGetMinY(_priceLabel.frame) - 18.5 - 40, CGRectGetWidth(self.frame) - 2*15, 40);
    _photoImageView.frame = CGRectMake(0, 0,CGRectGetWidth(self.frame) ,CGRectGetMinY(_describeLable.frame) -13.5);
     }else{
    _photoImageView.frame = CGRectMake(10 , (CGRectGetHeight(self.frame) - 80)/2 ,80 ,80);
    _describeLable.frame  = CGRectMake(CGRectGetMaxX(_photoImageView.frame) +15 , CGRectGetMinY(_photoImageView.frame), CGRectGetWidth(self.frame) -CGRectGetMaxX(_photoImageView.frame) -2*15, 20);
     _priceLabel.frame = CGRectMake( CGRectGetMaxX(_photoImageView.frame) + 10, CGRectGetHeight(self.frame) - 25 - 13.5f, 50, 25);
     _collectButton.frame =CGRectMake(CGRectGetWidth(self.frame)- 12 -25, CGRectGetHeight(self.frame) - 25 - 13.5 , 25, 25);
     _shoppingButton.frame =CGRectMake(CGRectGetWidth(self.frame) - 2*25 - 17 -12 , CGRectGetHeight(self.frame) - 25-13.5, 25, 25);
     }
}



#pragma mark - private method
- (void)_initUIFrame{
}

#pragma mark - action 
- (void)didTapShoppingButton : (UIButton *)sender{//点击了购物车
    if ([self.delegate respondsToSelector:@selector(cellDidClickShopping:)]) {
        [self.delegate cellDidClickShopping:self];
        sender.selected = !sender.selected;
        _productInfo.isCollected = sender.selected;
        if (sender.selected) {
            [sender setImage:[UIImage imageNamed:@"已加入购物车"] forState:UIControlStateSelected];
        }else{
            [sender setImage:[UIImage imageNamed:@"未加入购物车"] forState:UIControlStateNormal];
        }
        
        [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            sender.imageView.transform = CGAffineTransformTranslate(sender.imageView.transform, 20, 0);
        } completion:^(BOOL finished) {
        }];
    }
}

- (void)didTapCollectButton : (UIButton *)sender{//点击了收藏
    
     if ([self.delegate respondsToSelector:@selector(cellDidClickCollect:)]) {
         [self.delegate cellDidClickCollect:self];
         sender.selected = !sender.selected;
        _productInfo.isCollected = sender.selected;
         if (sender.selected) {
             [sender setImage:[UIImage imageNamed:@"已收藏"] forState:UIControlStateSelected];
         }else{
             [sender setImage:[UIImage imageNamed:@"未收藏"] forState:UIControlStateNormal];
         }
         
         [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
             sender.imageView.transform = CGAffineTransformScale(sender.imageView.transform , 2, 2);
         } completion:^(BOOL finished) {
             [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                 sender.imageView.transform = CGAffineTransformScale(sender.imageView.transform , 1, 1);
             } completion:^(BOOL finished) {
                 
             }];
         }];
    }
}

#pragma mark - get and setter
- (UIImageView *)photoImageView{
    if (!_photoImageView) {
        _photoImageView = [[UIImageView alloc] init];
        
    }
    return _photoImageView;
}

- (UILabel *)describeLable{
    if (!_describeLable) {
        _describeLable = [[UILabel alloc] init];
        _describeLable.font = [UIFont systemFontOfSize:13];
        _describeLable.numberOfLines =2 ;
    }
    return _describeLable;
}

- (UILabel *)priceLabel{
    if (!_priceLabel) {
        _priceLabel = [[UILabel alloc] init];
        _priceLabel.font = [UIFont systemFontOfSize:18];
        _priceLabel.textColor = kRBG(233, 56, 68);
    }
    return _priceLabel;
}

- (UIButton *)shoppingButton{
    if (!_shoppingButton) {
        _shoppingButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_shoppingButton setImage:[UIImage imageNamed:@"未加入购物车"] forState:0];
        [_shoppingButton addTarget:self action:@selector(didTapShoppingButton:) forControlEvents:UIControlEventTouchUpInside];

    }
        return _shoppingButton;
}

- (UIButton *)collectButton{
    if (!_collectButton) {
         _collectButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_collectButton setImage:[UIImage imageNamed:@"未收藏"] forState:0];
        [_collectButton addTarget:self action:@selector(didTapCollectButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _collectButton;
}

/**
 *  给单元格数据
 *
 *  @param productInfo
 */
- (void)setProductInfo:(XRTProductInfo *)productInfo{
    if (_productInfo != productInfo) {
        _productInfo  = productInfo;
         UIImage *image = [UIImage imageNamed:_productInfo.imagePath];
//        _imageViewHeigth = image.size.height;
//        _imageViewWidth  = image.size.width;
        _photoImageView.image = image;

        _describeLable.text = _productInfo.describeInfo;
        _shoppingButton.selected = _productInfo.isInStore;
        _shoppingButton.selected?[_shoppingButton setImage:[UIImage imageNamed:@"已加入购物车"] forState:UIControlStateSelected]:[_shoppingButton setImage:[UIImage imageNamed:@"未加入购物车"] forState:UIControlStateNormal];
        
        _collectButton.selected = _productInfo.isCollected;
        _collectButton.selected?[_collectButton setImage:[UIImage imageNamed:@"已收藏"] forState:UIControlStateSelected]:[_collectButton setImage:[UIImage imageNamed:@"未收藏"] forState:UIControlStateNormal];
        
        _priceLabel.text = _productInfo.priceInfo;
        [self setNeedsLayout];
    }
}

- (void)setType:(XRTCellDisplayType)type{
  _type = type;
  [self _initUIFrame];
}


@end
