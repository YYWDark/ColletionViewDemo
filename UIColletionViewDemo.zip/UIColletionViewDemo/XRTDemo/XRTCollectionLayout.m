//
//  XRTCollectionLayout.m
//  XRTDemo
//
//  Created by wyy on 16/11/14.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "XRTCollectionLayout.h"
    #import <CoreMotion/CoreMotion.h>

static const CGFloat distance = 15.0f;
static const NSUInteger numbersEachRow = 5;
@interface XRTCollectionLayout ()

@property (nonatomic, strong) NSMutableArray *layoutAttrinutes;
@property (nonatomic, strong) NSMutableArray *indexPathsToAnimate;
@property (nonatomic, strong) NSMutableArray *animationArr;
@end
@implementation XRTCollectionLayout
- (void)prepareLayout{
    [super prepareLayout];
    NSLog(@"prepareLayout3");
    for (int index = 0; index<[self.collectionView numberOfItemsInSection:0]; index++) {
        NSIndexPath *  indexPath =[NSIndexPath indexPathForItem:index inSection:0];
        UICollectionViewLayoutAttributes * attrs=[self layoutAttributesForItemAtIndexPath:indexPath];
        [self.layoutAttrinutes addObject:attrs];
    }
}
#pragma mark - override
-(UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionViewLayoutAttributes * attr=[UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
    
    CGFloat width = (self.collectionView.frame.size.width - (numbersEachRow+1)*distance)/numbersEachRow ;
    CGFloat height =width;
    CGFloat left = (distance + width)*(indexPath.row%numbersEachRow) + distance;
    CGFloat top  = (distance + height) *(indexPath.row/numbersEachRow) + distance;
    attr.frame = CGRectMake(left , top, width, height);
    return attr;
}

//// return an array layout attributes instances for all the views in the given rect
-(NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect{
//    int count =(int)[self.collectionView numberOfItemsInSection:0];
//    [self.layoutAttrinutes removeObjectAtIndex:0];
    NSMutableArray * array = [NSMutableArray array];
    for (int index = 0; index<[self.collectionView numberOfItemsInSection:0]; index++) {
        NSIndexPath *  indexPath =[NSIndexPath indexPathForItem:index inSection:0];
        UICollectionViewLayoutAttributes * attrs=[self layoutAttributesForItemAtIndexPath:indexPath];
        [array addObject:attrs];
    }
    return array;
}

//// Subclasses must override this method and use it to return the width and height of the collection view’s content
-(CGSize)collectionViewContentSize{
    int count =(int)[self.collectionView numberOfItemsInSection:0];
    CGFloat height =(self.collectionView.frame.size.width - (numbersEachRow+1)*distance)/numbersEachRow;
    NSInteger number = (count/numbersEachRow + ((count%numbersEachRow)?1:0));
    CGFloat totalHeight = number*(height +distance)+ distance ;
    return CGSizeMake(self.collectionView.frame.size.width,totalHeight);
}


#pragma mark - insert delete
- (UICollectionViewLayoutAttributes*)initialLayoutAttributesForAppearingItemAtIndexPath:(NSIndexPath *)itemIndexPath{

    UICollectionViewLayoutAttributes *attr = [self layoutAttributesForItemAtIndexPath:itemIndexPath];
    if ([self.animationArr containsObject:itemIndexPath]) {
        attr.transform = CGAffineTransformRotate(CGAffineTransformMakeScale(1, .1), 0);
        attr.alpha = 0;
        [_indexPathsToAnimate removeObject:itemIndexPath];
     
    }
    return attr;
}


- (UICollectionViewLayoutAttributes*)finalLayoutAttributesForDisappearingItemAtIndexPath:(NSIndexPath *)itemIndexPath
{
    UICollectionViewLayoutAttributes *attr = [self layoutAttributesForItemAtIndexPath:itemIndexPath];
    
    if ([_indexPathsToAnimate containsObject:itemIndexPath]) {
        [_indexPathsToAnimate removeObject:itemIndexPath];
    }
    else{
        attr.alpha = 1.0;
    }
    
    return attr;
}

- (void)prepareForCollectionViewUpdates:(NSArray *)updateItems{
    
    [super prepareForCollectionViewUpdates:updateItems];
    NSMutableArray *indexPaths = [NSMutableArray array];
    for (UICollectionViewUpdateItem *updateItem in updateItems) {
        switch (updateItem.updateAction) {
            case UICollectionUpdateActionInsert:
                [indexPaths addObject:updateItem.indexPathAfterUpdate];
                break;
            case UICollectionUpdateActionDelete:
                [indexPaths addObject:updateItem.indexPathBeforeUpdate];
                break;
            case UICollectionUpdateActionMove:
                [indexPaths addObject:updateItem.indexPathBeforeUpdate];
                [indexPaths addObject:updateItem.indexPathAfterUpdate];
                break;
            default:
                break;
        }
    }
    self.animationArr = [indexPaths mutableCopy];
}

- (void)finalizeCollectionViewUpdates
{
    NSLog(@"%@ finalize updates", self);
    [super finalizeCollectionViewUpdates];
    self.indexPathsToAnimate = nil;
}
#pragma mark - get
- (NSMutableArray *)layoutAttrinutes{
    if (_layoutAttrinutes == nil) {
        _layoutAttrinutes = [NSMutableArray array];
    }
    return _layoutAttrinutes;
}
@end
