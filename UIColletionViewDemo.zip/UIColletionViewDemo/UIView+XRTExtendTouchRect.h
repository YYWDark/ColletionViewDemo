//
//  UIView+XRTExtendTouchRect.h
//  XRTDemo
//
//  Created by wyy on 16/5/17.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (XRTExtendTouchRect)
/**
 *  扩大视图点击区域
 *
 *  @param touchExtendInset 
 */
- (void)setTouchExtendInset:(UIEdgeInsets)touchExtendInset;
@end
