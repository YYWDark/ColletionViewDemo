//
//  XRTHeader.h
//  XRTDemo
//
//  Created by wyy on 16/11/11.
//  Copyright © 2016年 yyx. All rights reserved.
//

#ifndef XRTHeader_h
#define XRTHeader_h
#import "UIColor+Extension.h"

#define kScreenHeigth [UIScreen mainScreen].bounds.size.height
#define kScreenWidth  [UIScreen mainScreen].bounds.size.width
#define kRBG(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0  blue:b/255.0  alpha:1]

typedef NS_ENUM(NSInteger, XRTCellDisplayType) {
    XRTCellDisplayTypeLarger = 0,
    XRTCellDisplayTypeSmaller = 1,
};

#endif /* XRTHeader_h */
