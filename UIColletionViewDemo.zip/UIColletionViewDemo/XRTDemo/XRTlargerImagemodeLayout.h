//
//  XRTlargerImagemodeLayout.h
//  XRTDemo
//
//  Created by wyy on 16/11/11.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XRTlargerImagemodeLayout : UICollectionViewFlowLayout

@end
