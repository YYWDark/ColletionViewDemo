//
//  XRTProductListView.m
//  XRTDemo
//
//  Created by wyy on 16/5/16.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "XRTProductListView.h"
#import "XRTProductListViewCell.h"
#import "XRTProductInfo.h"
#import "XRTlargerImagemodeLayout.h"
#import "XRTSmallerImagePattenLayout.h"
#import "XRTHeader.h"
#define XRTProductListViewIdentifer @"XRTProductListViewCell"


@interface XRTProductListView()<XRTProductResponseCellDelegate,UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic ,strong) NSMutableArray *fakeArr;
@property (nonatomic ,strong) UICollectionView *collctionView;  /**< 商品浏览器*/
@property (nonatomic, assign) XRTCellDisplayType type;

@property (nonatomic, strong) XRTlargerImagemodeLayout *largerLayout;
@property (nonatomic, strong) XRTSmallerImagePattenLayout *smallerLayout;
@end
@implementation XRTProductListView
#pragma mark - life circle
- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.type = XRTCellDisplayTypeLarger;
        //创造假数据
        NSMutableArray *arr = [NSMutableArray array];
        _fakeArr = [NSMutableArray array];
        for (int index = 0 ; index < 24; index ++) {
            XRTProductInfo *info = [[XRTProductInfo alloc] init];
            info.imagePath = [NSString stringWithFormat:@"商品%d",index%6+1];
            info.describeInfo = @"国行Apple/苹果智能手表apple watch苹果";
            info.priceInfo = @"¥365";
            info.isInStore = index%3;
            info.isCollected = index%2;
            [arr addObject:info];
        }
        [_fakeArr addObjectsFromArray:arr];
        [self addSubview:self.collctionView];
    }
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];
     self.frame = self.bounds;
}

- (void)updateFlowLayout{
    if ([self.collctionView.collectionViewLayout isMemberOfClass:[XRTlargerImagemodeLayout class]]) {
        self.type = XRTCellDisplayTypeSmaller;
        [self updateAllCellDisplayType:XRTCellDisplayTypeSmaller];
        [self.collctionView setCollectionViewLayout:self.smallerLayout animated:YES];
        
    }else if([self.collctionView.collectionViewLayout isMemberOfClass:[XRTSmallerImagePattenLayout class]]){
         self.type = XRTCellDisplayTypeLarger;
        [self updateAllCellDisplayType:XRTCellDisplayTypeLarger];
        [self.collctionView setCollectionViewLayout:self.largerLayout animated:YES];
       
    }

}

- (void)updateAllCellDisplayType:(XRTCellDisplayType)type{
    for (int index = 0; index < _fakeArr.count; index++) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
     XRTProductListViewCell *cell = (XRTProductListViewCell *)[self.collctionView cellForItemAtIndexPath:indexPath];
        cell.type = type;
    }
}

#pragma mark - UIcollectionView dataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return _fakeArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    XRTProductListViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:XRTProductListViewIdentifer forIndexPath:indexPath];
    cell.type = self.type;
    cell.delegate  = self;
    XRTProductInfo *info = _fakeArr[indexPath.row];
    cell.productInfo = info;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"选中了单元格");
}

#pragma mark - XRTProductResponseCellDelegate
- (void)cellDidClickCollect:(XRTProductListViewCell *)cell{
    NSLog(@"点击了收藏");
}

- (void)cellDidClickShopping:(XRTProductListViewCell *)cell{
    NSLog(@"点击了购物车");
}

#pragma mark - get
- (UICollectionView *)collctionView{
    if (!_collctionView) {
        
        //设置滑动的方向
        _collctionView = [[UICollectionView alloc] initWithFrame: CGRectMake(0, 0,self.frame.size.width , self.frame.size.height ) collectionViewLayout:self.largerLayout];
        _collctionView.backgroundColor = kRBG(230, 231, 233);
        
        //签订协议
        _collctionView.dataSource = self;
        _collctionView.delegate   =self;
        
        //注册cell
        [_collctionView registerClass:[XRTProductListViewCell class] forCellWithReuseIdentifier:XRTProductListViewIdentifer];
        
        
    }
    return _collctionView;
}

- (XRTSmallerImagePattenLayout *)smallerLayout{
    if (_smallerLayout == nil ) {
        _smallerLayout = [[XRTSmallerImagePattenLayout alloc] init];
        [_smallerLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    }
    return _smallerLayout;
}

- (XRTlargerImagemodeLayout *)largerLayout{
    if (_largerLayout == nil ) {
        _largerLayout = [[XRTlargerImagemodeLayout alloc] init];
    }
    return _largerLayout;
}


@end
