//
//  XRTProductResponseCellDelegate.h
//  XRTDemo
//
//  Created by wyy on 16/5/16.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import <Foundation/Foundation.h>

@class XRTProductListViewCell;
@protocol XRTProductResponseCellDelegate <NSObject>
@optional
//点击了购物
- (void)cellDidClickShopping : (XRTProductListViewCell *)cell;
//点击了收藏
- (void)cellDidClickCollect : (XRTProductListViewCell *)cell;
@end
