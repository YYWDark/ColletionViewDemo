//
//  ViewController.m
//  XRTDemo
//
//  Created by wyy on 16/5/16.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "ViewController.h"
#import "XRTProductListView.h"
//#define kRBG(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0  blue:b/255.0  alpha:1]
@interface ViewController ()
@property (nonatomic, strong) XRTProductListView *listView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton*rightButton = [[UIButton alloc]initWithFrame:CGRectMake(0,0,30,30)];
    [rightButton setImage:[UIImage imageNamed:@"largerImagePatten.png"]forState:UIControlStateNormal];
    [rightButton addTarget:self action:@selector(exchangeIcon:) forControlEvents:UIControlEventTouchUpInside];
    rightButton.selected = NO;
    UIBarButtonItem*rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightButton];
    self.navigationItem.rightBarButtonItem= rightItem;
    
    
    _listView = [[XRTProductListView alloc] initWithFrame:CGRectMake(0, 64, self.view.frame.size.width,self.view.frame.size.height  )];
    [self.view addSubview:_listView];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)exchangeIcon:(UIButton *)sender{
    [sender setImage:sender.selected?[UIImage imageNamed:@"largerImagePatten"]:[UIImage imageNamed:@"samllImagePatten"] forState:UIControlStateNormal];
    [_listView updateFlowLayout];
    sender.selected = !sender.selected;
}
@end
