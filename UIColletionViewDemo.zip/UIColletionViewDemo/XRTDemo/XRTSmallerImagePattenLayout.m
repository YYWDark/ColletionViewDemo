//
//  XRTSmallerImagePattenLayout.m
//  XRTDemo
//
//  Created by wyy on 16/11/11.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "XRTSmallerImagePattenLayout.h"
static const CGFloat smallerHeight = 100.0f;
static const CGFloat verticalDistance = 1.0;

@interface XRTSmallerImagePattenLayout ()

@property (nonatomic, strong) NSMutableArray *layoutAttrinutes;

@end

@implementation XRTSmallerImagePattenLayout
- (void)prepareLayout{
    [super prepareLayout];
    NSLog(@"prepareLayout2");
    for (int index = 0; index<[self.collectionView numberOfItemsInSection:0]; index++) {
        NSIndexPath *  indexPath =[NSIndexPath indexPathForItem:index inSection:0];
        UICollectionViewLayoutAttributes * attrs=[self layoutAttributesForItemAtIndexPath:indexPath];
        [self.layoutAttrinutes addObject:attrs];
    }
}
#pragma mark - override
-(UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat width =self.collectionView.frame.size.width ;
    CGFloat height =smallerHeight;
    UICollectionViewLayoutAttributes * attrs=[UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
    attrs.frame = CGRectMake(0, (height + verticalDistance)*(indexPath.row) , width, height);
    return attrs;
}

//// return an array layout attributes instances for all the views in the given rect
-(NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect
{
    return self.layoutAttrinutes;
}

//// Subclasses must override this method and use it to return the width and height of the collection view’s content
-(CGSize)collectionViewContentSize
{
    int count =(int)[self.collectionView numberOfItemsInSection:0];
    CGFloat height =smallerHeight;
    CGFloat totalHeight = height*count + verticalDistance *(count-1);
    return CGSizeMake(self.collectionView.frame.size.width,totalHeight);
}

#pragma mark - get
- (NSMutableArray *)layoutAttrinutes{
    if (_layoutAttrinutes == nil) {
        _layoutAttrinutes = [NSMutableArray array];
    }
    return _layoutAttrinutes;
}

@end
