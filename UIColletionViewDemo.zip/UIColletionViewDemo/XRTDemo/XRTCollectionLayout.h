//
//  XRTCollectionLayout.h
//  XRTDemo
//
//  Created by wyy on 16/11/14.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XRTCollectionLayout : UICollectionViewLayout
@property (nonatomic, strong) NSIndexPath *selectedIndexpath;
@end
