//
//  XRTProductInfo.h
//  XRTDemo
//
//  Created by wyy on 16/5/16.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface XRTProductInfo : NSObject
@property (nonatomic ,copy) NSString *imagePath;     /**< 图片URL*/
@property (nonatomic ,copy) NSString *describeInfo;  /**< 商品描述信息*/
@property (nonatomic ,copy) NSString *priceInfo;     /**< 价格信息*/
@property (nonatomic ,copy) NSString *pcoductType;   /**< 产品了类型*/
@property (nonatomic ,copy) NSString *brandInfo;     /**< 品牌信息*/
@property (nonatomic ,copy) NSString *coreType;      /**< 内核类别*/
@property (nonatomic ,assign) BOOL isInStore;        /**< 是否添加在购物车*/
@property (nonatomic ,assign) BOOL isCollected;      /**< 是否被收藏*/
@end
